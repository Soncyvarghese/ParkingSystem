#Table Structure

There are 3 master tables namely Slots,Users and Bookings.Slots table consist of slot no and status. Status is using to identify the slot availability.Users table have all the required fileds that already mentioned in the requirement document. Booking table have two foreign keys like slot_id and user_id.

#implementation

API for slot creation:
To create slots (as requirement - A01 - Z05).

API for appointment:
To schedule an appointment. If a customer come to the parking, system will collect the required customer details like name,mobileno,vehicleno etc. System also checking if the customer already exists or not. If the customer already exist system will directly leads to the appointment. if its not exists system will create a customer and then leads to booking.
before creating appointment system will automatically check if the slots are available or not.
System also update the start_date and slot status= ACTIVE.

API for check out:
While customer is going for an checkout. system will calculate the parking fee as per the project requirement. At the same time system will update the bookind end_date and slot status as INACTIVE.

API for customer list:
Customer with total fee collected (as against customer).

API for upcomming appointments list:
As per the requirement it not fully clear. We can only create available slot list. Not implemented.

#For improvement:
If a user can have multiple vechicle we can create a new uservechicle table. If system want to implement different  parking fee we can create a ParkingFee table as well.


