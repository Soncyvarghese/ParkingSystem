<!DOCTYPE html>
<h3>User List</h3>
<table >
    <thead>
        <tr>
            <th style="border: 1px solid black;">Name</th>
            <th style="border: 1px solid black;">Mobile</th>
            <th style="border: 1px solid black;">Vehicle Number</th>
            <th style="border: 1px solid black;">Total Collected</th>
        </tr>
    </thead>
    <tbody>
           <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td style="border: 1px solid black;"> <?php echo e($user->name); ?> </td>
                <td style="border: 1px solid black;"> <?php echo e($user->mobile); ?> </td>
                <td style="border: 1px solid black;"> <?php echo e($user->vehicle_number); ?> </td>
                <td style="border: 1px solid black;"> <?php echo e($user->total_pay); ?> </td>
            </tr>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </tbody>
</table>
</html>
<?php /**PATH /var/www/html/parking-slot-appointment/resources/views/user.blade.php ENDPATH**/ ?>