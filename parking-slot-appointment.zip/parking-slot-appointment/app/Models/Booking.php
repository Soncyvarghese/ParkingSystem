<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Booking extends Model
{
    use HasFactory;

    protected $table = 'bookings';

    protected function getLastBookingEntry()
    {
        return $this->orderBy('id','DESC')
                    ->first();
    }

    protected function saveData($data)
    {
        return $this->insertGetId($data);
    }

    protected function checkEntryExists($userId)
    {
        return $this->where('user_id',$userId)
                    ->where('end_date','=',NULL)
                    ->first();
    }

    protected function checkAppointmentNumberExist($number)
    {
        return $this->where('appointment_number',$number)
                    ->first();
    }

    protected function updateData($data,$number){
       
        return $this->where('appointment_number','=',$number)
                    ->update($data);
    }

}
