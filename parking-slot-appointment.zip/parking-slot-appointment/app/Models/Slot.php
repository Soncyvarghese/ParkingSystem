<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Slot extends Model
{
    use HasFactory;

    protected $table = 'slots'; 

    protected function getSlotData()
    { 
        return $this->where('status','INACTIVE')
                ->first();
             
    }

    protected function updateData($data,$id){
       
        return $this->where('id','=',$id)
                    ->update($data);
    }

    protected function checkSlotExist($name)
    { 
        return $this->where('slot',$name)
                    ->first();
             
    }

    protected function insertData($data)
    {
        return $this->insertGetId($data);
    }

}
