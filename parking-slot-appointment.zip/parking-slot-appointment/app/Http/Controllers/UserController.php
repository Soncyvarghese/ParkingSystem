<?php

namespace App\Http\Controllers;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Http\Request;
use App\Models\Booking;
use App\Models\User;
use App\Models\Slot;

class UserController extends Controller
{
    public function add(Request $request){
        try {
            $params = $request->validate([
              'name' => 'required',
              'mobile' => 'required|max:10|min:10',
              'vehicle_number' => 'required',
              'file' => 'required',
              'duration'=> 'required'
            ]);
            $slotData=Slot::getSlotData();
            if($slotData){
              $exist=User::checkNumberExists($request->mobile);
              if(!$exist){
                $image=$_FILES['file'];
                $ext=pathinfo($image['name'],PATHINFO_EXTENSION);
                $file_name=$request->mobile.'_license.'.$ext;
                $folder=realpath(__DIR__ . "/../../../uploads") . "/".$file_name;
                move_uploaded_file($image['tmp_name'], $folder);
                  $data=array(
                      'name'=>$request->name,
                      'mobile'=>$request->mobile,
                      'vehicle_number'=>$request->vehicle_number,
                      'license'=>$file_name,
                      'created_at'=>date('Y-m-d H:i:s'),
                      'updated_at'=>date('Y-m-d H:i:s')
                    );
                  $userId=User::saveData($data);
              }else{
                  $userId=$exist['id'];
              }
              $checkEntry=Booking::checkEntryExists($userId);
              if(!$checkEntry){
                $bookingArray=$this->saveBooking($request->duration,$userId,$slotData);
                if(!empty($bookingArray)){
                  $array=[
                    'status'  => true,
                    'message' => "Successfully Booked.",
                    'data'    => $bookingArray
                  ];
                  return response()->json($array);die;
                }else{
                  $array=[
                    'status'  => false,
                    'message' => "Booking Failed",
                    'data'    => [],
                  ];
                  return response()->json($array);die;
                }
              }else{
                $array=[
                  'status'  => false,
                  'message' => "Appointment already done for this vehicle",
                  'data'    => [],
                ];
                return response()->json($array);die;
              }
            }else{
              $array=[
                'status'  => false,
                'message' => "No slot available",
                'data'    => [],
              ];
              return response()->json($array);die;
            }
        }
        catch(\Exception $e){
          $array=[
            'status'=>false,
            'message'=>$e->getMessage(),
            'data'=>[],
          ];
          return response()->json($array);die;
        }
      }

      protected function saveBooking($duration,$userId,$slotData){
        try {
              $appData=[];
              $data=Booking::getLastBookingEntry();
              $bookingNumber=$data['appointment_number'] ?? 'A01AAA';
              $number1=substr($bookingNumber,-3);
              $number1++;
              $appointment_number=$slotData['slot'].$number1;
              $bookingData=array(
                'user_id'=>$userId,
                'duration'=>$duration,
                'slot_id'=>$slotData['id'],
                'appointment_number'=>$appointment_number,
                'start_date'=>date('Y-m-d H:i:s'),
                'created_at'=>date('Y-m-d H:i:s'),
                'updated_at'=>date('Y-m-d H:i:s')
              );
              $bookingId=Booking::saveData($bookingData);
              if($bookingId){
                $slotsdata=array(
                  'status'=>'ACTIVE',
                  'updated_at'=>date('Y-m-d H:i:s')
                );
                Slot::updateData($slotsdata,$slotData['id']);
                $appData['appointment_number']=$appointment_number;
                $appData['slot_number']=$slotData['slot'];
                $minutes=$duration*60;
                $cost=$this->calculateCost($minutes);
                $appData['expected_parking_fee']=$cost;
                return $appData;
              }
           
        } catch(\Exception $e){
          $array=[
            'status'=>false,
            'message'=>$e->getMessage(),
            'data'=>[],
          ];
          return response()->json($array);die;
        }

      }

      public function calculateCost($minutes){
        try {
           if($minutes<=180){
             $cost=10;
           }else if($minutes>180 && $minutes<1440){
              $diff=$minutes-180;
              $extraPayment=($diff/60)*5;
              $cost=10+$extraPayment;
           }else{
              $diff=$minutes-180;
              $extraPayment=($diff/60)*5;
              $days=ceil($minutes/24);
              $cost=10+$extraPayment+($days*100);
           }
           return $cost;
        } catch(\Exception $e){
            $array=[
              'status'=>false,
              'message'=>$e->getMessage(),
              'data'=>[],
            ];
            return response()->json($array);die;
        }
      }

      public function checkout(Request $request){
        try {
          $params = $request->validate([
            'appointment_number' =>'required'
          ]);
          $exist=Booking::checkAppointmentNumberExist($request->appointment_number);
          if($exist){
            $start_date=new \DateTime($exist['start_date']);
              $end_date=new \DateTime(date('Y-m-d H:i:s'));
              $difference=$start_date->diff($end_date);
              $minutes=$difference->days*24*60 +
                       $difference->h*60 +
                       $difference->i +
                      ($difference->s)/60;
              $cost=$this->calculateCost($minutes);
            $bookingData=array('end_date'=>date('Y-m-d H:i:s'),
                                'fee_collected'=>$cost,
                                'updated_at'=>date('Y-m-d H:i:s'));
            $update=Booking::updateData($bookingData,$request->appointment_number);
            if($update){
              $slotData=array('status'=>'INACTIVE',
                              'updated_at'=>date('Y-m-d H:i:s'));
              $updateSlot=Slot::updateData($slotData,$exist['slot_id']);
              $checkoutData['checkout_fee']=$cost;
              $array=[
                'status'  => true,
                'message' => "Successfully Checkout.",
                'data'    =>$checkoutData
              ];
              return response()->json($array);die;
            }
          }else{
            $array=[
              'status'  => false,
              'message' => "Appointment number not found",
              'data'    => [],
            ];
            return response()->json($array);die;
          }
        } catch(\Exception $e){
            $array=[
              'status'=>false,
              'message'=>$e->getMessage(),
              'data'=>[],
            ];
            return response()->json($array);die;
        }
      }


      public function list(){
        try {
          $users = User::getUserData();
          return view('user', compact('users'));
        }catch(\Exception $e){
          $array=[
            'status'=>false,
            'message'=>$e->getMessage(),
            'data'=>[],
          ];
          return response()->json($array);die;
      }
        
      }

      public function createSlot(Request $request){
        try {
          for($char='A';$char<='Z05';$char++) {
            for($i=1;$i<=5;$i++) {    
                $slot=$char.'0'.$i;
                if($slot=='AA01'){
                  $array=[
                    'status'  => true,
                    'message' => "Successfully Added.",
                    'data'    =>[]
                  ];
                  return response()->json($array);die;
                }
                $data=Slot::checkSlotExist($slot);
                if(!$data){
                  $slotData=array('slot'=>$slot,'status'=>'INACTIVE','updated_at'=>date('Y-m-d H:i:s'));
                  $id=Slot::insertData($slotData);
                }
            }
          }
        }
        catch(\Exception $e){
          $array=[
            'status'=>false,
            'message'=>$e->getMessage(),
            'data'=>[],
          ];
          return response()->json($array);die;
        }
      }

}
