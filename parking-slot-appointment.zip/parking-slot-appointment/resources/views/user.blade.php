<!DOCTYPE html>
<h3>User List</h3>
<table >
    <thead>
        <tr>
            <th style="border: 1px solid black;">Name</th>
            <th style="border: 1px solid black;">Mobile</th>
            <th style="border: 1px solid black;">Vehicle Number</th>
            <th style="border: 1px solid black;">Total Collected</th>
        </tr>
    </thead>
    <tbody>
           @foreach($users as $user)
            <tr>
                <td style="border: 1px solid black;"> {{$user->name}} </td>
                <td style="border: 1px solid black;"> {{$user->mobile}} </td>
                <td style="border: 1px solid black;"> {{$user->vehicle_number}} </td>
                <td style="border: 1px solid black;"> {{$user->total_pay}} </td>
            </tr>
           @endforeach
     </tbody>
</table>
</html>
